from django.db import models

# Create your models here.


class Route(models.Model):
    datetime = models.DateTimeField(auto_now=True)
    raw_data = models.CharField(max_length=10000)

    def __str__(self):
        return f"Route #{self.id} {self.datetime} with points: {self.raw_data}"

    def all_days(self):
        return RouteDay.objects.filter(route_id=self.id).order_by('number')

    def oxygen(self):
        return sum([x.oxygen for x in self.all_days()])

    def fuel(self):
        return sum([x.fuel for x in self.all_days()])


class Point(models.Model):
    route = models.ForeignKey(Route, on_delete=models.CASCADE)
    distance = models.FloatField('Расстояние')
    sh = models.IntegerField('Количество товара')
    number = models.IntegerField('Порядковый номер точки')

    def __str__(self):
        return f"Точка #{self.number}. Расстояние {self.distance}, ожидает {self.sh} товара."


class RouteDay(models.Model):
    number = models.IntegerField
    route_id = models.ForeignKey(Route, on_delete=models.CASCADE)
    oxygen = models.IntegerField()
    fuel = models.IntegerField()






