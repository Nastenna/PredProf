from django.shortcuts import render
from . models import Route, RouteDay, Point

from . import get_input

# Create your views here.


def new_route(request):
    route_info = get_input.get_data()[0]
    raw_data = str(route_info['points'])
    try:
        route = Route.objects.get(raw_data=raw_data)
    except:
        route = None
    if not route:
        route = Route.objects.create(raw_data=raw_data)
        point_counter = 1
        points = list()
        for p in route_info['points']:
            points.append(Point.objects.create(route=route, number=point_counter, distance=p['distance'], sh=p['SH']))
            point_counter += 1
    else:
        points = Point.objects.filter(route=route)

    return render(request, 'express/route.html', {'route': route, 'points': points})
