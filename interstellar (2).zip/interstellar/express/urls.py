from django.urls import path
from . import views

urlpatterns = [
    path('new_route/', views.new_route, name='route'),
]
