import requests

import json


def request_data():
   headers = {
      'X-Auth-Token': ''
   }
   r = requests.get("https://dt.miet.ru/ppo_it_final", headers=headers)
   return r.content


def get_data(request = False):
    if request:
        data = request_data()
    else:
        data = """
{
    "message": [
        {
            "points": [
                {
                    "SH": 504,
                    "distance": 42
                }
            ]
        },
        {
            "points": [
                {
                    "SH": 248,
                    "distance": 21
                },
                {
                    "SH": 120,
                    "distance": 49
                },
                {
                    "SH": 504,
                    "distance": 48
                }
            ]
        },
        {
            "points": [
                {
                    "SH": 5,
                    "distance": 17
                },
                {
                    "SH": 7,
                    "distance": 12
                }
            ]
        }
    ]
}
"""
    return json.loads(data)['message']

if __name__ == '__main__':
    values = get_data()

    for v in values:
        print(v)
