import math

V_max = 2
M_empty = 192
sh = 8


def m(sh):
    return M_empty + sh


def v(w, m):
    return V_max * (w / 80) * (200 / m)


def g(g0, k):
    return math.floor(g0 + g0 * k)


def k(t, oxi):
    return math.sin(-math.pi / 2 + (math.pi * (t + 0.5 * oxi) / 40))


def e(t):
    return int(t * (t + 1) / 2)


def count(total_distance):
    sh = 8
    for i in range(20, 101):
        days_counter = 0
        days_counted = False
        while not days_counted:
            distance = v(100 - i, m(sh))