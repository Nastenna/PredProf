# цена кислорода
OXYGEN_PRICE = 14 / 2

# цена топлива
FUEL_PRICE = OXYGEN_PRICE * 10 / 7
