from django.test import TestCase

from . models import Point, Route
from .get_input import get_data
# Create your tests here.


class TestRoute(TestCase):
    def test_create(self):
        data = get_data()
        routes = [Route(raw_data=str(x['points'])) for x in data]
        for route in routes:
            print(route)


class TestPoint(TestCase):
    def test_create(self):
        points = dict()
        for data in get_data():
            route = Route(raw_data=str(data['points']))
            counter = 1
            for p in data['points']:
                point = Point(route_id=route.id,
                              number=counter,
                              distance=p['distance'],
                              sh=p['SH'])
                counter += 1
                print(point)


